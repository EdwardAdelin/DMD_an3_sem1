package com.example.project

data class RecurrentExpense(val name: String, val value: Double)